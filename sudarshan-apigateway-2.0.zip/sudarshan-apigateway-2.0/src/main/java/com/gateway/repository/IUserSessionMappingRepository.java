package com.gateway.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gateway.model.UserTokenSessionMapping;

public interface IUserSessionMappingRepository extends JpaRepository<UserTokenSessionMapping, Long>{

	UserTokenSessionMapping findByUserId(Long userId);
	UserTokenSessionMapping findBySessionId(String sessionId);
}
