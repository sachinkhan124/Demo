package com.gateway.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.gateway.model.UserOrg;

public interface IUserOrgRepository extends JpaRepository<UserOrg, Long>{
     
    @Query("SELECT uo FROM UserOrg uo WHERE uo.userId.userLoginId = ?1")
	List<UserOrg> findByUserLoginId(String userLoginId);
}
