package com.gateway.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gateway.model.Users;

public interface IUsersRepository extends JpaRepository<Users,Integer> {

    List<Users>  findByUserLoginId(String userLoginId);
}
