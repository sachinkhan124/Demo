/**
 * Author: Ajay Patil
 * Date:16/10/23
 */
package com.gateway.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gateway.exception.InvalidTokenException;
import com.gateway.model.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

@Component
@Slf4j
public class TokenAuthenticationFilter extends AbstractGatewayFilterFactory {

    @Autowired
    private TokenDecoder tokenDecodercheck;

    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) throws InvalidTokenException {
        ServerHttpRequest request = exchange.getRequest();
        log.info("Remote Excange "+exchange.toString());
        log.info("Remote "+request.getRemoteAddress());
        //log.info("LOcal "+request.getLocalAddress());
        if(exchange.getRequest().getPath().toString().equals("/sudarshan/authenticate") || exchange.getRequest().getPath().toString().equals("/sudarshan/matchOtp")
        		|| exchange.getRequest().getPath().toString().equals("/api/logs/preActivity") 
        		|| exchange.getRequest().getPath().toString().equals("/usermgmt/forgotSecurityCode")
        		|| exchange.getRequest().getPath().toString().equals("/usermgmt/changePasswordForUserOrNodal")
        		|| exchange.getRequest().getPath().toString().equals("/py/getUrlForMediaCertificate")
        		|| exchange.getRequest().getPath().toString().equals("/user/save/vpnuser")
        		|| exchange.getRequest().getPath().toString().equals("/user/nacuser/save")){
            log.info("Token validation processing Completed, Authentication API : valid Token.");
            return chain.filter(exchange);
        }
        if (!request.getHeaders().containsKey("Token")) {
        	log.error("Token key is missing...!!!");
            return this.onError(exchange, "Token is missing...!!!", HttpStatus.FORBIDDEN);
        }
        
        String token = request.getHeaders().getOrEmpty("Token").get(0);
       
        
        if(!request.getHeaders().containsKey("guest")) {
        	log.error("guest is missing");
            return this.onError(exchange, "Invalid user...!!!", HttpStatus.UNAUTHORIZED);

        }
        String cipher = request.getHeaders().getOrEmpty("tune").get(0);
        if(!request.getHeaders().containsKey("tune")) {
        	log.error("tune is missing");
            return this.onError(exchange, "Invalid user...!!!", HttpStatus.UNAUTHORIZED);
        };
        
        String guest = request.getHeaders().getOrEmpty("guest").get(0);
               
        if (token.isEmpty() || token.isBlank()) {
            log.error("Token value is empty...!!!");
            return this.onError(exchange, "Token is empty...!!!", HttpStatus.FORBIDDEN);
        }
        
        String session = this.tokenDecoder(exchange, token, guest,cipher);
        if(session == null){
            
            log.error("Invalid user...!!");
            return this.onError(exchange, "Invalid user...!!!", HttpStatus.UNAUTHORIZED);
        }else {
        	ServerHttpRequest modifiedRequest = request.mutate()
                    .header("session", session)
                    .build();

            // Update the exchange with the modified request
            ServerWebExchange modifiedExchange = exchange.mutate()
                    .request(modifiedRequest)
                    .build();
            log.info("User Validate successfully.");
            return chain.filter(modifiedExchange);
        }
    }

    private String tokenDecoder(ServerWebExchange exchange, String token, String guest, String cipher) throws InvalidTokenException {
        log.info("Token validation processing... ");
        String session = tokenDecodercheck.validateToken(token, guest,cipher);
        if(session != null){
            log.info("Token validation processing Completed, valid Token.");
            return session;
        }else {
            log.info("Token validation processing Completed, Invalid Token...!!!");
            return null;
        }
    }


    private Mono<Void> onError(ServerWebExchange exchange, String err, HttpStatus httpStatus) {
        ServerHttpResponse response = exchange.getResponse();
        ApiResponse<Object> apiResponse = ApiResponse.builder().status(String.valueOf(httpStatus))
                .statusCode(httpStatus.value())
                .message(err)
                .build();
        response.setStatusCode(httpStatus);
        response.getHeaders().setContentType(org.springframework.http.MediaType.APPLICATION_JSON);
        DataBuffer dataBuffer = null;
        try {
            dataBuffer = response.bufferFactory().wrap(new ObjectMapper().writeValueAsBytes(apiResponse));
        } catch (JsonProcessingException e) {
            log.error("Facing during parsing json...!!!");
            throw new RuntimeException("Facing during parsing json...!!!");
        }
        return response.writeWith(Mono.just(dataBuffer));
    }

    @Override
    public GatewayFilter apply(Object config) {
        return (exchange, chain) -> {
            try {
                return this.filter(exchange,chain);
            } catch (Exception e) {
                return this.onError(exchange, e.getMessage(), HttpStatus.UNAUTHORIZED);
            }
        };

    }
}