/**
 * Author: Ajay Patil
 * Date:16/10/23
 */
package com.gateway.utils;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jasypt.encryption.StringEncryptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.gateway.exception.InvalidTokenException;
import com.gateway.model.UserOrg;
import com.gateway.model.UserTokenSessionMapping;
import com.gateway.repository.IUserOrgRepository;
import com.gateway.repository.IUserSessionMappingRepository;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class TokenDecoder {
    
    @Autowired
    private IUserOrgRepository userOrgRepository;
    
    @Autowired
    private IUserSessionMappingRepository usersSessionMappingRepository;

	@Autowired
	@Qualifier("jasyptStringEncryptor")
	StringEncryptor encrypter;
	

	
    public String validateToken(String accessToken, String guest, String cipher) throws InvalidTokenException {
    	
        log.info("Inside validateToken() Method");
        if (accessToken.isBlank()) {
            log.error("Please check Input, Token or username is empty...!!!");
            throw new InvalidTokenException("Please check Input, Token or username is empty...!!!");
        }
        accessToken = encrypter.decrypt(accessToken);
        DecodedJWT decodedJWT = decodeToken(accessToken);
  
        return verifyPayload(decodedJWT,guest,cipher);

    }


    private DecodedJWT decodeToken(String accessToken) throws InvalidTokenException {
    	
        log.info("Inside decodeToken() Method");
        try {
            return JWT.decode(accessToken);
        } catch (Exception ex) {
            log.error("Please check Input, Token decoding failed...!!!");
            throw new InvalidTokenException("Token is InvalidTokenException ");
        }
    }


    private String verifyPayload(DecodedJWT decodedJWT, String guest,String cipher) throws InvalidTokenException {
        log.info("Inside verifyPayload() Method");

        JsonObject payloadAsJson = decodeTokenPayloadToJsonObject(decodedJWT);
        
       if (hasTokenExpired(payloadAsJson)) {
            log.error("Please check Input, Token has expired...!!!");
            throw new InvalidTokenException("Token has expired");
        }

        String brokerName = getDecoded(decodedJWT).get("sub");

        if(brokerName == null || brokerName.isBlank()){
            brokerName = getDecoded(decodedJWT).get("preferred_username");

        }
        if(!brokerName.isBlank()) {

 //           List<Users> user =usersRepository.findByUserLoginId(brokerName.replaceAll("\"", ""));
        	List<UserOrg> userOrg = userOrgRepository.findByUserLoginId(brokerName.replaceAll("\"", ""));
            if(userOrg.size() == 1  && userOrg.get(0).getUserId().getUserId().equals(Long.parseLong(guest)) 
            		&& userOrg.get(0).getOrgId().getIsActive() && userOrg.get(0).getUserId().getIsActive().equals(1)) {
            	log.info("User validate successfully with Ref{}: "+userOrg.get(0).getUserId().getUserId());
            	UserTokenSessionMapping userSessionMapping = usersSessionMappingRepository.findByUserId(userOrg.get(0).getUserId().getUserId());
                if (userSessionMapping.getSessionId().equals(passDecryption(userSessionMapping.getKey(),cipher)) && userSessionMapping.getIsActive().equals(1)) {
                	return userSessionMapping.getSessionId();
                }else {
                	 log.error("Please check Input, Session is not matched or is inactive");
                     return null;
                }
            }else {
                log.error("Please check Input, User not found with given token ref{}: "+brokerName);
                return null;
 //               throw new InvalidTokenException("Please check input, Token is invalid.");
            }
        }else {
            log.error("Please check Input, Token is invalid, Failed to extract userName...!!!");
            throw new InvalidTokenException("Please check input, Token is invalid.");
        }
    }

    private Map<String, String> getDecoded(DecodedJWT decodedJWT) {
        log.info("Inside getDecoded() method with Input request:{} ");
        String payloadAsString = decodedJWT.getPayload();
        return new Gson().fromJson(new String(Base64.getDecoder().decode(payloadAsString), StandardCharsets.UTF_8),
                HashMap.class);
    }



    private JsonObject decodeTokenPayloadToJsonObject(DecodedJWT decodedJWT) throws InvalidTokenException {
        log.info("Inside decodeTokenPayloadToJsonObject() Method");
        try {
            String payloadAsString = decodedJWT.getPayload();
            return new Gson().fromJson(new String(Base64.getDecoder().decode(payloadAsString), StandardCharsets.UTF_8),
                    JsonObject.class);
        } catch (RuntimeException exception) {
            log.error("Please check Input, Invalid JWT or JSON format of each of the jwt parts...!!!");
            throw new InvalidTokenException("Invalid JWT or JSON format of each of the jwt parts", exception);
        }
    }

    private boolean hasTokenExpired(JsonObject payloadAsJson) throws InvalidTokenException {
        log.info("Inside hasTokenExpired() Method");
        Instant expirationDatetime = extractExpirationDate(payloadAsJson);
        log.info("Is Token Expire : "+Instant.now().isAfter(expirationDatetime));
        return Instant.now().isAfter(expirationDatetime);
    }

    private Instant extractExpirationDate(JsonObject payloadAsJson) throws InvalidTokenException {
        log.info("Inside extractExpirationDate() Method");
        try {
            log.info("EXP Date : "+Instant.ofEpochSecond(payloadAsJson.get("exp").getAsLong()));
            return Instant.ofEpochSecond(payloadAsJson.get("exp").getAsLong());
        } catch (RuntimeException ex) {
            log.error("Please check Input,There is no 'exp' claim in the token payload...!!!");
            throw new InvalidTokenException("There is no 'exp' claim in the token payload");
        }
    }
    
    private  String passDecryption(String key, String encryptedText) {

		return AESUtil.decrypt(encryptedText,key);
	}



}
