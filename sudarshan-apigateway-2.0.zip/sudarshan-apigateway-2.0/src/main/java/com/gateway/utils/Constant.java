/**
 * Author: Ajay Patil
 * Date:16/10/23
 */
package com.gateway.utils;

public class Constant {
    public static final String BAD_REQUEST = "BAD_REQUEST";
    public static final String OK = "OK";
    public static final String SERVER_SIDE_ERROR = "Something went wrong on serverside...!!!";
    public static final String UNAUTHORIZED = "UNAUTHORIZED";
    public static final String INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR";
    public static final String NOT_FOUND = " NOT_FOUND";

}
