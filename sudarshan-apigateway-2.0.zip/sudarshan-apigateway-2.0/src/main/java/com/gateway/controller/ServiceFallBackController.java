/**
 * Author: Ajay Patil
 * Date:16/10/23
 */
package com.gateway.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.gateway.model.ApiResponse;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class ServiceFallBackController {

    @RequestMapping(value = "/sudarshanMasterService", method = { RequestMethod.GET, RequestMethod.POST }, produces = "application/json")
    public ResponseEntity<Object> sudarshanMasterService() {
        ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
                .statusCode(HttpStatus.BAD_GATEWAY.value())
                .message("CALLING - SERVICE IS DOWN, PLEASE TRY AFTER SOMETIME !!!")
                .build();
        log.error("FallbackMethod() call, response {}: "+apiResponse.getMessage());
        return new ResponseEntity<>(apiResponse,HttpStatus.BAD_GATEWAY);
    }

    @RequestMapping(value = "/sudarshanFoldermanagementService", method = { RequestMethod.GET, RequestMethod.POST }, produces = "application/json")
    public ResponseEntity<Object> getSudarshanFoldermanagementService() {
        ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
                .statusCode(HttpStatus.BAD_GATEWAY.value())
                .message("CALLING - SERVICE IS DOWN, PLEASE TRY AFTER SOMETIME !!!")
                .build();
        log.error("FallbackMethod() call, response {}: "+apiResponse.getMessage());
        return new ResponseEntity<>(apiResponse,HttpStatus.BAD_GATEWAY);
    }

    @RequestMapping(value = "/sudarshanADService", method = { RequestMethod.GET, RequestMethod.POST }, produces = "application/json")
    public ResponseEntity<Object> sudarshanADService() {
        ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
                .statusCode(HttpStatus.BAD_GATEWAY.value())
                .message("CALLING - SERVICE IS DOWN, PLEASE TRY AFTER SOMETIME !!!")
                .build();
        log.error("FallbackMethod() call, response {}: "+apiResponse.getMessage());
        return new ResponseEntity<>(apiResponse, HttpStatus.BAD_GATEWAY);
    }
    
    @RequestMapping(value = "/sudarshanPythonMiddlewareService", method = { RequestMethod.GET, RequestMethod.POST }, produces = "application/json")
    public ResponseEntity<Object> getsudarshanPythonMiddlewareService() {
        ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
                .statusCode(HttpStatus.BAD_GATEWAY.value())
                .message("CALLING - SERVICE IS DOWN, PLEASE TRY AFTER SOMETIME !!!")
                .build();
        log.error("FallbackMethod() call, response {}: "+apiResponse.getMessage());
        return new ResponseEntity<>(apiResponse,HttpStatus.BAD_GATEWAY);
    }
    
    @RequestMapping(value = "/sudarshan", method = { RequestMethod.GET, RequestMethod.POST }, produces = "application/json")
    public ResponseEntity<Object> sudarshan() {
        log.info("Start inside sudarshan()");
        ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK))
                .statusCode(HttpStatus.OK.value()).success(true)
                .message("You Are Good To Go !!!")
                .build();
        log.info("Certificate accepted call, response {}: "+apiResponse.getMessage());
//        return new ResponseEntity<>(apiResponse,HttpStatus.OK);
        return new ResponseEntity<>("You Are Good To Go.",HttpStatus.OK);
    }

    /**
     * This API is used for  Application Performance Monitoring (APM)
     * @author Aditya P.
     * @return
     */
    @GetMapping("/Sudarshan_API_Gateway-heartbeat/monitor")
	public ResponseEntity<Object> heartbeat() {
		log.info("In ServiceFallBackController :Inside heartbeat()");
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message("SUCCESS").data("Alive").build();
		log.info("[ServiceFallBackController.heartbeat] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
}
