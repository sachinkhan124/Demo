/**
 * Author: Ajay Patil
 * Date:11/12/23
 */
package com.gateway.model;

import java.time.LocalDateTime;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "M_USER")
public class Users {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "USER_ID",nullable = false)
    private Long userId;

    @Column(name = "USER_LOGIN_ID",nullable = false)
    private String userLoginId;

    @Column(name = "USER_NAME",nullable = false)
    private String userName;

    @Column(name = "USER_ADDRESS",nullable = true)
    private String userAddress;

    @Column(name = "USER_EMAIL_ID",nullable = true)
    private String userEmailId;

    @Column(name = "USER_CONTACT_NO",nullable = true)
    private Long userContactNo;

    @Column(name = "UPDATED_EMAIL_ID",nullable = true)
    private String updatedEmailId;

    @Column(name = "UPDATED_CONTACT_NO",nullable = true)
    private Long updatedContactNo;

    @Column(name = "IS_APPROVED",nullable = true)
    private String userApproved;

    @Column(name = "PROFILE_UPDATE_REMARKS",nullable = true)
    private String profileUpdateRemarks;

    @Column(name = "REMARKS",nullable = true)
    private String remarks;

    @Column(name = "ENCCODE",nullable = false)
    private String encCode;

    @Column(name = "CREATED_BY",nullable = false)
    private Long createdBy;

    @CreationTimestamp
    @Column(name = "CREATED_ON",nullable = false)
    private LocalDateTime createdOn;

    @Column(name = "IS_ACTIVE",nullable = false)
    private Integer isActive = 1;

    @Column(name = "IS_NODAL",nullable = false)
    private String isNodal;

    @Column(name = "IS_PASSWORD_FLAG",nullable = false)
    private Integer isPasswdFlag;

    @Column(name = "ONE_TIME_PASSWORD",nullable = false)
    private String oneTimePassword;
    
	@Column(name = "IS_AGREE")
	private Boolean isAgree;
	
	@Column(name = "IS_NAC_CREATED", nullable = false, columnDefinition = "boolean default false")
	private Boolean isNacCreated = false;
	
	@Column(name = "IS_VPN_CREATED", nullable = false, columnDefinition = "boolean default false")
	private Boolean isVpnCreated = true;

}

