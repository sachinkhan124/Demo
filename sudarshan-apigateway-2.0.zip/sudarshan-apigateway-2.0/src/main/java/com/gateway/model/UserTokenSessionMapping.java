package com.gateway.model;

import java.time.LocalDateTime;

import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@Data
@NoArgsConstructor	
@AllArgsConstructor
@Entity
@Table(name = "USER_SESSION_MAPPING")
public class UserTokenSessionMapping {
		
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SESSION_MAPPING_ID",nullable = false)
	private Long sessionMappingId;
		
	@Column(name = "USER_ID",nullable = false)
	private Long userId;
		
	@Column(name = "IS_ACTIVE",nullable = false)
	private Integer isActive;
		
	@Column(name = "TOKEN",nullable = false)
	private String token;
	
	@Column(name = "SESSION_ID",nullable = false)
	private String sessionId;
	
	@Column(name = "ENCRYPTION_KEY",nullable = false)
	private String key;
	
	@UpdateTimestamp
	@Column(name = "TOKEN_GENERATION_TIME")
	private LocalDateTime tokenGenerationTIme;
		
}
