/**
 * Author: Ajay Patil
 * Date:20/11/23
 */
package com.gateway.model;

import java.sql.Timestamp;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.Valid;
//import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Valid
@Entity
@Table(name = "M_ORG")
public class Org {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ORG_ID", unique = true, nullable = false)
	private Integer orgId;

	@Column(name = "CREATED_BY", nullable = false, updatable = false)
	private Integer createdBy;

	@Column(name = "ORG_TYPE_ID", nullable = false)
	private Integer orgTypeId;

	@CreationTimestamp
	@Column(name = "CREATED_ON", nullable = false, updatable = false)
	private Timestamp createdOn;

	@Column(name = "IS_ACTIVE", nullable = false)
	private Boolean isActive;

	@Column(name = "ORG_ADDR")
	private String orgAddr;

	@Column(name = "ORG_ALIAS", nullable = false)
	private String orgAlias;

	@Column(name = "ORG_CONTACT_NO")
	private Long orgContactNo;

	@Column(name = "ORG_NAME", nullable = false)
	private String orgName;

	@Column(name = "Remarks")
	private String remarks;
	
	@Column(name = "IS_STATE", nullable = false)
	private Boolean isState;
	
	@Column(name = "ORG_PASSCODE")
	private String orgPasscode;
	
	@ManyToOne(fetch = FetchType.LAZY,  optional = true)
	@JoinColumn(name = "STATE_ID", nullable = true )
	private OrgState orgState;

	// bi-directional many-to-one association to OrgType
	@JsonBackReference(value = "orgType")
	@ManyToOne(fetch = FetchType.LAZY, cascade = { CascadeType.ALL }, optional = false)
	@JoinColumn(name = "ORG_TYPE_ID", nullable = false, updatable = false, insertable = false)
	private OrgType orgType;

	// bi-directional many-to-one association to OrgPortal


}
