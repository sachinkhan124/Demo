package com.gateway.model;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "M_USER_ORG")
public class UserOrg {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "USER_ORG_MAP_ID",nullable = false)
	private Long userOrgMapId;
	
	@Column(name = "CREATED_BY",nullable = false)
	private Long createdBy;
	
	@CreationTimestamp
	@Column(name = "CREATED_ON",nullable = false)
	private LocalDateTime createdOn;
	
	@Column(name = "IS_ACTIVE",nullable = false)
	private Integer isActive = 1;
	
	@ManyToOne
	@JoinColumn(name = "ORG_ID", nullable = false)
	private Org orgId;
	
	@ManyToOne
	@JoinColumn(name = "USER_ID", nullable = false)
	private Users userId;

}
