/**
 * Author: Ajay Patil
 * Date:20/11/23
 */
package com.gateway.model;

import java.sql.Timestamp;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="M_ORG_TYPE")
public class OrgType {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ORG_TYPE_ID", unique=true, nullable=false)
	private Integer orgTypeId;

	@Column(name="CREATED_BY", nullable=false,updatable = false)
	private Integer createdBy;

	@CreationTimestamp
	@Column(name="CREATED_ON", nullable=false,updatable = false)
	private Timestamp createdOn;

	@Column(name="IS_ACTIVE", nullable=false)
	private Boolean isActive;

	@Column(name="ORG_TPE_DESC")
	private String orgTpeDesc;

	@Column(name="ORG_TYPE_ALIAS", nullable=false)
	private String orgTypeAlias;

	@Column(name="ORG_TYPE_NAME", nullable=false)
	private String orgTypeName;


}
