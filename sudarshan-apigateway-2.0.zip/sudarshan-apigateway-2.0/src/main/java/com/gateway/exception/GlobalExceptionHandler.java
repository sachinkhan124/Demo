/**
 * Author: Ajay Patil
 * Date:16/10/23
 */
package com.gateway.exception;

import com.gateway.model.ApiResponse;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;


@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler  {

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> globleExcpetionHandler(Exception ex) {
        log.error("ERROR : "+ex.getMessage());
        ApiResponse<Object> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR))
                .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
                .message(ex.getMessage())
                .build();
        return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }


    @ExceptionHandler(InvalidTokenException.class)
    public ResponseEntity<Object> invalidTokenException(InvalidTokenException ex) {
        log.error("Error : "+ex.getMessage());
        ApiResponse<Object> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.UNAUTHORIZED))
                .statusCode(HttpStatus.UNAUTHORIZED.value())
                .message(ex.getMessage())
                .build();
        return new ResponseEntity<>(apiResponse, HttpStatus.UNAUTHORIZED);
    }
}
