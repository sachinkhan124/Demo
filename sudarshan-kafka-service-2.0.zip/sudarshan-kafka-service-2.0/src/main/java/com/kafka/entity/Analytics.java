package com.kafka.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class Analytics {

	private String articleId;
	private String sentiment;
	private String ner;
	private String domain_identification;
	private String summary;
	private String coref;
	private String relation_extraction;

}
