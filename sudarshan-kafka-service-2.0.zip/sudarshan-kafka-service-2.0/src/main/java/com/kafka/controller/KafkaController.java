package com.kafka.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.kafka.entity.Analytics;
import com.kafka.entity.MediaEntity;
import com.kafka.service.IProducerService;
import com.kafka.util.ApiResponse;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class KafkaController {

	@Autowired
	private IProducerService producerService;

	List<Analytics> analytics = new ArrayList<>();
	Long off = 0L;

	@PostMapping("/kafka/publish")
	public String publishMessage(@RequestBody List<String> articleIds) {
		log.info("START - KafkaController - inside publishMessage() method");
		return producerService.sendJsonData(articleIds);
	}

	@PostMapping("/kafka/publishImageMedia")
	public String publishImageMedia(@RequestBody List<MediaEntity> mediaEntity) {
		log.info("START - KafkaController - inside publishImageMedia() method");
		return producerService.sendImageJsonData(mediaEntity);
	}

	@PostMapping("/kafka/publishProfileFinderData")
	public String publishProfileFinderData(@RequestBody List<Object> Data) {
		log.info("START - KafkaController - inside publishProfileFinderData() method");
		return producerService.publishProfileFinderData(Data);
	}

	@PostMapping("/kafka/publishVideoMedia")
	public String publishVideoMedia(@RequestBody List<MediaEntity> mediaEntity) {
		log.info("START - KafkaController - inside publishVideoMedia() method");
		return producerService.sendVideoJsonData(mediaEntity);
	}

	@GetMapping("/kafka/consume")
	public Map<String, Object> consumerMessage() {
		log.info("START - KafkaController - inside consumerMessage() method");
		Map<String, Object> map = new HashMap<>();
		map.put("analytics", analytics);
		map.put("offset", off);
		return map;
	}

	/**
     * This API is used for  Application Performance Monitoring (APM)
     * @author Aditya P.
     * @return
     */
    @GetMapping("/kafka-heartbeat/monitor")
	public ResponseEntity<Object> heartbeat() {
		log.info("In KafkaController :Inside heartbeat()");
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message("SUCCESS").data("Alive").build();
		log.info("[KafkaController.heartbeat] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
}
