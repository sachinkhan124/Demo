package com.kafka.util;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ApiResponse<T> {

	private String message;
    private String status;
    private Integer statusCode;
    private boolean success;
    private T data;

}
