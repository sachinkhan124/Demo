package com.kafka.config;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;



@Component
public class KafkaParameters {

	@Value("${kafka.group}")
    private String kafkaGroup;
	
	@Value("${kafka.profilefinder.topic}")
    private String kafkaTopic;
	
	public String getProfileFinderTopic() {
	    return kafkaTopic;
	}
	    
	public String getProfileFinderGroup() {
	    return kafkaGroup;
	}
}
