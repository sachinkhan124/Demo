package com.kafka.service;


import java.util.List;



import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.annotation.KafkaListener;


import java.io.IOException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProfileFinderInsertionService {
     
		@Autowired
		RestTemplate restTemplate;
		
		
		@Value("${es.ingestion.api}")
		private String esIngestionUrl;
		
		
        	@KafkaListener(topics = "#{kafkaParameters.getProfileFinderTopic()}", 
				groupId = "#{kafkaParameters.getProfileFinderGroup()}", 
				containerFactory = "jsonKafkaListenerContainerFactory")
	    public void listenToTopic(List<Object> dataList){
			try {
			
				esIngestion(dataList);
			} catch (IOException e) {
				log.error("EsInsertionService - Unable to insert record in ES " + dataList);
			} catch (InterruptedException e) {
				log.error("EsInsertionService - error while thread sleep" );
			}
	    }
		
        private void esIngestion(List<Object> dataList) throws IOException, InterruptedException {
        	 
	        	  HttpEntity<List<Object>> requestEntity = new HttpEntity<>(dataList);
	        	  ResponseEntity<String> result = restTemplate.postForEntity(esIngestionUrl, requestEntity, 
	        			  String.class);
	        	  if(!result.getBody().equalsIgnoreCase("success")) {
	        		  esIngestion(dataList);
	        	  }
	        	
        }
}
