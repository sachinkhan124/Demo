package com.kafka.service;

import java.util.List;

import com.kafka.entity.MediaEntity;

public interface IProducerService{

	String sendJsonData(List<String> articleIds);

	String publishProfileFinderData(List<Object> data);

	String sendImageJsonData(List<MediaEntity> mediaEntity);

	String sendVideoJsonData(List<MediaEntity> mediaEntity);

}
