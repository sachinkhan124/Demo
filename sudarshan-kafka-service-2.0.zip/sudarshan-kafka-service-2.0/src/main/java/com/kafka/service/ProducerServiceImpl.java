package com.kafka.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.kafka.entity.MediaEntity;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProducerServiceImpl implements IProducerService {

	@Autowired
	private KafkaTemplate<Object, Object> kafkaTemplate;

	@Value("${kafka.topic}")
	private String kafkaTopic;

	@Value("${kafka.image.topic}")
	private String imageTopic;
	
	@Value("${kafka.profilefinder.topic}")
	private String kafkaPfTopic;

	@Value("${kafka.video.topic}")
	private String videoTopic;

	@Override
	public String sendJsonData(List<String> articleIds) {
		log.debug("In ProducerService - inside sendJsonData() method with payload: " + articleIds);
		kafkaTemplate.send(kafkaTopic, articleIds);
		log.info("Data published in kafaka");
		return "Data published!!";
	}

	@Override
	public String sendImageJsonData(List<MediaEntity> mediaEntity) {
		log.debug("In ProducerService - inside sendImageJsonData() method with payload: " + mediaEntity);
		kafkaTemplate.send(imageTopic, mediaEntity);
		log.info("Image data published in kafaka");
		return "Image data published!!";
	}

	@Override
	public String publishProfileFinderData(List<Object> data) {
		log.info("In ProducerService - inside publishProfileFinderData() method");
		kafkaTemplate.send(kafkaPfTopic, data);
		log.info("Data published in kafka");
		return "Data published!!";
	}

	@Override
	public String sendVideoJsonData(List<MediaEntity> mediaEntity) {
		log.debug("In ProducerService - inside sendVideoJsonData() method with payload: " + mediaEntity);
		kafkaTemplate.send(videoTopic, mediaEntity);
		log.info("Video data published in kafaka");
		return "Video data published!!";
	}

}
