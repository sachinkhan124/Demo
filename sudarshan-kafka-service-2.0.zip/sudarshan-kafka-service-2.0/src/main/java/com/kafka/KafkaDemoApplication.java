package com.kafka;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.Resource;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.Arrays;
import java.util.List;

import javax.net.ssl.SSLContext;

@SpringBootApplication
@EnableEncryptableProperties
public class KafkaDemoApplication {

	@Value("${server.ssl.key-store}")
    private Resource trustStore;

    @Value("${server.ssl.key-store-password}")
    private String trustStorePassword;

    @Value("#{'${cors.allowed.origin.list}'.split(',')}")
	private List<String> corsOriginAllowedList;
    
	public static void main(String[] args) {
		SpringApplication.run(KafkaDemoApplication.class, args);
	}
	
	@Bean
	CorsConfigurationSource corsConfigurationSource() {

		final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		CorsConfiguration config = new CorsConfiguration();
		source.registerCorsConfiguration("/**", config.applyPermitDefaultValues());
		config.setAllowedOrigins(corsOriginAllowedList);
		config.setExposedHeaders(Arrays.asList("Authorization"));
		config.setAllowedMethods(Arrays.asList("GET","POST","PUT","DELETE"));
		return source;
	}
	
   	@Bean
   	@Primary
   	@LoadBalanced
    public RestTemplate restTemplate() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException,
         CertificateException, IOException {        
                 
                 SSLContext sslContext = new SSLContextBuilder()
                   .loadTrustMaterial(trustStore.getURL(), trustStorePassword.toCharArray()).build();
                 
                 SSLConnectionSocketFactory sslConFactory = new SSLConnectionSocketFactory(sslContext);

                 CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(sslConFactory).build();
                 ClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
                 return new RestTemplate(requestFactory);
                 
             }

}
